/********************************************************************************
** Form generated from reading UI file 'Laboratoire1.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LABORATOIRE1_H
#define UI_LABORATOIRE1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Laboratoire1Class
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Laboratoire1Class)
    {
        if (Laboratoire1Class->objectName().isEmpty())
            Laboratoire1Class->setObjectName(QString::fromUtf8("Laboratoire1Class"));
        Laboratoire1Class->resize(600, 400);
        menuBar = new QMenuBar(Laboratoire1Class);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        Laboratoire1Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Laboratoire1Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        Laboratoire1Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(Laboratoire1Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        Laboratoire1Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(Laboratoire1Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        Laboratoire1Class->setStatusBar(statusBar);

        retranslateUi(Laboratoire1Class);

        QMetaObject::connectSlotsByName(Laboratoire1Class);
    } // setupUi

    void retranslateUi(QMainWindow *Laboratoire1Class)
    {
        Laboratoire1Class->setWindowTitle(QCoreApplication::translate("Laboratoire1Class", "Laboratoire1", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Laboratoire1Class: public Ui_Laboratoire1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LABORATOIRE1_H
