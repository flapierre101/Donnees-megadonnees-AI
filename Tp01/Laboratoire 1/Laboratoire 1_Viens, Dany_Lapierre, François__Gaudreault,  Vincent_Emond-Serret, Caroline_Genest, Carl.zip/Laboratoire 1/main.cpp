#include "Laboratoire1.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Laboratoire1 w;
    w.show();
    return a.exec();
}
